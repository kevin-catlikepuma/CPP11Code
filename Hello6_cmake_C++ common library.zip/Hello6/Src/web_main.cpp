#include <iostream>
#include <string>
#include "crow_all.h"
#include "json11.hpp"

std::string HelloWorld()
{
    return "Hello World !!!";
}

crow::response bottles(int count)
{
    if (count > 100)
    {
        /* code */
        return crow::response(400);
    }

    std::ostringstream os;
    os << count << " bottles of beer!";
    return crow::response(os.str());
    
}

std::function<std::string()> func = HelloWorld;
std::function<crow::response (int count)> func_bottlres = bottles;

int main()
{
    crow::SimpleApp app;

    CROW_ROUTE(app, "/")([](){
        return "Hello, This is Root path";
    });

    CROW_ROUTE(app, "/hello")(func);

    CROW_ROUTE(app, "/bottle/<int>")(func_bottlres);

    CROW_ROUTE(app, "/add_json").methods("POST"_method)
    ([](const crow::request& req){
        auto x = crow::json::load(req.body);
        if (!x)
            return crow::response(400);
        int sum = x["a"].i()+x["b"].i();
        std::ostringstream os;
        os << sum;
        return crow::response{os.str()};
    });

    CROW_ROUTE(app, "/json")
    ([]{
        crow::json::wvalue x;
        x["message"] = "Hello, World!";
        // return x;

        using namespace json11;

        const Json obj = Json::object({
            { "k1", "v1" },
            { "k2", 42.0 },
            { "k3", Json::array({ "a", 123.0, true, false, nullptr }) },
        });

        return obj.dump();
    });

    app.port(9080).multithreaded().run();
    return 0;
}