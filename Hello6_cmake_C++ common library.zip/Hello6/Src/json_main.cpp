#include <cassert>
#include <string>
#include<iostream>
#include <unordered_map>
#include "json11.hpp"


// using namespace std;

using namespace json11;
using std::string;

#define JSON11_TEST_ASSERT(b) assert(b)

int main()
{
    const string simple_test = R"({"k1":"v1", "k2":42, "k3":["a",123,true,false,null]})";

    string err;
    const auto json = Json::parse(simple_test, err);

    std::cout << "k1: " << json["k1"].string_value() << std::endl;
    std::cout << "k3: " << json["k3"].dump() << "\n";

    for (auto &k : json["k3"].array_items()) 
    {
        std::cout << "    - " << k.dump() << "\n";
    }

    std::map<string, string> m1 { { "k1", "v1" }, { "k2", "v2" } };
    std::unordered_map<string, string> m2 { { "k1", "v1" }, { "k2", "v2" } };
    JSON11_TEST_ASSERT(Json(m1) == Json(m2));

    // Json literals
    const Json obj = Json::object({
        { "k1", "v1" },
        { "k2", 42.0 },
        { "k3", Json::array({ "a", 123.0, true, false, nullptr }) },
    });

    std::cout << "obj: " << obj.dump() << "\n";
    JSON11_TEST_ASSERT(obj.dump() == "{\"k1\": \"v1\", \"k2\": 42, \"k3\": [\"a\", 123, true, false, null]}");

    std::cout << obj.object_items().size() << std::endl;

    auto json_object = obj.object_items();
    for(auto objItem : json_object)
    {
        std::cout << objItem.first.c_str() << " kevin " << objItem.second.dump() << std::endl;

    }

    JSON11_TEST_ASSERT(Json("a").number_value() == 0);
    JSON11_TEST_ASSERT(Json("a").string_value() == "a");
    JSON11_TEST_ASSERT(Json().number_value() == 0);

    JSON11_TEST_ASSERT(obj == json);
    JSON11_TEST_ASSERT(Json(42) == Json(42.0));
    JSON11_TEST_ASSERT(Json(42) != Json(42.1));


    return 0;
}