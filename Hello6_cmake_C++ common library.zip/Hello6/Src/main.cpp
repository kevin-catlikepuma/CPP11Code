//
// Created by kevin on 2021/1/13.
//
// #include "../libhello/hello.h"
#include <sys/types.h>
#include <vector>
#include<iostream>
#include "hello.h"
#include <string>
#include <tinyxml.h>
#include "spdlog.h"
#include "sinks/stdout_color_sinks.h"
#include "fmt/core.h"
#include "fmt/ranges.h"

void use_tinyxml()
{
    TiXmlDocument* myDocument = new TiXmlDocument();
    myDocument->LoadFile("Students.xml");
    TiXmlElement* rootElement = myDocument->RootElement();  //Class
    std::string strRoot = rootElement->Value();
    std::cout<< "Root Element: " << strRoot << std::endl;
    TiXmlElement* studentsElement = rootElement->FirstChildElement();  //Students
    TiXmlElement* studentElement = studentsElement->FirstChildElement();  //Students
    while ( studentElement ) 
    {
        TiXmlAttribute* attributeOfStudent = studentElement->FirstAttribute();  //获得student的name属性
        while ( attributeOfStudent ) 
        {
            std::cout << attributeOfStudent->Name() << " : " << attributeOfStudent->Value() << std::endl;
            attributeOfStudent = attributeOfStudent->Next();
        }

        TiXmlElement* phoneElement = studentElement->FirstChildElement();//获得student的phone元素
        std::cout << "phone" << " : " << phoneElement->GetText() << std::endl;
        TiXmlElement* addressElement = phoneElement->NextSiblingElement();
        std::cout << "address" << " : " << phoneElement->GetText() << std::endl;
        studentElement = studentElement->NextSiblingElement();
    }
}

#include "sinks/rotating_file_sink.h"
void rotating_example()
{
    // Create a file rotating logger with 5mb size max and 3 rotated files
    auto max_size = 1048576 * 5;
    auto max_files = 3;
    auto logger = spdlog::rotating_logger_mt("some_logger_name", "logs/rotating.txt", max_size, max_files);

    spdlog::set_default_logger(logger);

    spdlog::info("***************************");
    std::cout << "Log Name:" << logger->name() << std::endl;
    for (int i = 0; i < 101; i++)
    {
        logger->info("Message #{}" , i);

        logger->error("Error Message #{}", i);
    }
    logger->flush();
}

void spdlog_stdout()
{
    auto console = spdlog::stdout_color_mt("console");
    spdlog::get("console")->info("This is console");

}

int main()
{    
    //use_tinyxml();
    // std::wstring wstr_ret = say_hello(L"world");
    // std::wcout << L"say_hello return value: " << wstr_ret << std::endl;

    // std::wstring wstr_ret2 = say_hello2(L"world2");
    // std::wcout << L"say_hello2 return value: " << wstr_ret2 << std::endl;

    // fmt::print("Hello, World!");

    // std::string fmt_str = fmt::format("The answer is {}.", 42);

    // std::cout << fmt_str << std::endl;
    spdlog::info("Welcome to spdlog!");
    rotating_example();

    std::string fmt_str = fmt::format("The answer is {}", 42);

    std::cout << "FMT Format: " << fmt_str << std::endl;

    std::vector<int> vec = {1,2,3,4};
    auto vec_str = fmt::format("The vector content : {}", vec);
    std::cout << "FMT vector content: " << vec_str << std::endl;

    return 0;
}
