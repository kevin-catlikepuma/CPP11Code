#include "yaml-cpp/yaml.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "yaml-cpp/node/type.h"

void creadt_node()
{
    YAML::Node node;  // starts out as null
    node["key"] = "value";  // it now is a map node
    node["seq"].push_back("first element");  // node["seq"] automatically becomes a sequence
    node["seq"].push_back("second element");

    node["mirror"] = node["seq"][0];  // this creates an alias
    node["seq"][0] = "1st element";  // this also changes node["mirror"]
    node["mirror"] = "element #1";  // and this changes node["seq"][0] - they're really the "same" node

    node["self"] = node;  // you can even create self-aliases
    node[node["mirror"]] = node["seq"];  // and strange loops :)

    auto str_value = YAML::key_to_string(node);

    std::cout << str_value.c_str() << std::endl;

    std::cout << "#############################" << std::endl;
}

void native_convert()
{
    YAML::Node node = YAML::Load("{pi: 3.14159, [0, 1]: integers}");

    // this needs the conversion from Node to double
    double pi = node["pi"].as<double>();

    // this needs the conversion from double to Node
    node["e"] = 2.71828;

    // this needs the conversion from Node to std::vector<int> (*not* the other way around!)
    std::vector<int> v;
    v.push_back(0);
    v.push_back(1);
    std::string str = node[v].as<std::string>();

}

struct Vec3 { double x, y, z; /* etc - make sure you have overloaded operator== */ };

namespace YAML {
template<>
struct convert<Vec3> {
    static Node encode(const Vec3& rhs) 
    {
        Node node;
        node.push_back(rhs.x);
        node.push_back(rhs.y);
        node.push_back(rhs.z);
        return node;
    }

    static bool decode(const Node& node, Vec3& rhs) 
    {
        if(!node.IsSequence() || node.size() != 3) 
        {
            return false;
        }

        rhs.x = node[0].as<double>();
        rhs.y = node[1].as<double>();
            rhs.z = node[2].as<double>();
        return true;
    }
};
}

void custom_covert()
{
    YAML::Node node = YAML::Load("start: [1, 3, 0]");
    Vec3 v = node["start"].as<Vec3>();
    
    std::cout << v.x << v.y << v.z << std::endl;

    YAML::convert<Vec3> vec_abc;
    
    auto temp_vec = Vec3{2, -1, 0};
    node["end"] = vec_abc.encode(temp_vec);

    auto str_value = YAML::key_to_string(node);

    std::cout << str_value.c_str() << std::endl;
}

int main()
{
    custom_covert();
    creadt_node();
    YAML::Node config = YAML::LoadFile("config.yaml");
    auto str_value = YAML::key_to_string(config);
    
    if (config.IsMap())
    {
        for (YAML::iterator ybeg = config.begin(); ybeg != config.end(); ++ybeg)
        {
            std::cout << ybeg->first.as<std::string>() << std::endl;

            std::cout << YAML::key_to_string(ybeg->first.as<std::string>()) << std::endl;
            std::cout << "****************************" << std::endl;

            if(ybeg->second.IsMap())
            {
                std::cout << YAML::key_to_string(ybeg->second) <<std::endl;
            }
        }
        
    }

    std::cout << config.IsMap() << std::endl;
    std::cout << config.IsNull() << std::endl;
    std::cout << config.IsScalar() << std::endl;
    std::cout << config.IsDefined() << std::endl;
    std::cout << config.Type() << std::endl;

    auto _name = config.Scalar();
    auto _tag = config.Tag();
    auto _size = config.size();

    std::cout << _name << _tag << _size << std::endl;

    std::cout << "#######################" << std::endl;
   
   return 0;
}