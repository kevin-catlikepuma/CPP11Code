//
// Created by kevin on 2021/1/13.
//
#include<iostream>
#include "hello.h"
std::wstring wsTemp = L"Hello ";

const wchar_t* say_hello(const wchar_t *pwsName)
{
    wsTemp = L"Hello "; //init value
    wsTemp += pwsName;

    std::wcout << L"say_hello: " << wsTemp << std::endl;
    return wsTemp.c_str();
}

const wchar_t* say_hello2(const wchar_t * pwsName)
{
    wsTemp = L"Hello ";
    wsTemp += pwsName;

    std::wcout << L"say_hello2: " << wsTemp << std::endl;
    return wsTemp.c_str();
}