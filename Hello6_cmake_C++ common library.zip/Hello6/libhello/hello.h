//
// Created by kevin on 2021/1/13.
//

#ifndef HELLO4_HELLO_H
#define HELLO4_HELLO_H


extern "C" const wchar_t* say_hello(const wchar_t *pwsName);
extern "C" const wchar_t* say_hello2(const wchar_t * pwsName);
#endif //HELLO4_HELLO_H
